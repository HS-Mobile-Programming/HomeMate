// IngredientDictionaryRepository
// Firestore "ingredients" 컬렉션에서 재료 사전 데이터를 읽어오는 역할입니다.
// AI 추천 로직, 매핑 로직 작업에서 사용을 위한 목적으로 만들었습니다.

import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/ingredient_dictionary.dart';
import '../services/local_ingredient_dict_cache.dart';

class IngredientDictionaryRepository {
  final FirebaseFirestore _db;
  final LocalIngredientDictCache _cache = LocalIngredientDictCache();

  IngredientDictionaryRepository({FirebaseFirestore? db})
      : _db = db ?? FirebaseFirestore.instance;

  // 전체 재료 사전 가져오기 (로컬 우선 + 필요 시 Firestore 동기화)
  Future<List<IngredientDictionary>> fetchAllDictionaries() async {
    List<IngredientDictionary> list = [];

    // 1) 먼저 로컬(Hive)에서 시도
    try {
      list = _cache.getAll();
    } catch (e, st) {
      // 큰 문제 없도록 로그만 남기고 빈 리스트로
      // debugPrint('[IngredientDictionaryRepository] local load error: $e\n$st');
      list = [];
    }

    final needServerSync =
        list.isEmpty || !_cache.isSyncedToday();

    // 2) 로컬이 비어있거나 오늘 동기화 안 했으면 Firestore에서 새로 가져오기 시도
    if (needServerSync) {
      try {
        final snapshot = await _db.collection('ingredients').get();
        final fetched = snapshot.docs
            .map((doc) => IngredientDictionary.fromJson(doc.data(), doc.id))
            .toList();

        await _cache.saveAll(fetched);
        list = fetched;
      } catch (e, st) {
        // 서버 실패 시: 로컬에 남아있는 list(있으면)만 사용
        // debugPrint('[IngredientDictionaryRepository] Firestore load error: $e\n$st');
      }
    }

    return list;
  }

  // 특정 재료(id 기준) 가져오기 (예: id = "간장")
  Future<IngredientDictionary?> fetchById(String id) async {
    // 1) 먼저 로컬 캐시에서 검색
    try {
      final all = _cache.getAll();
      final local = all.firstWhere(
            (e) => e.id == id,
        orElse: () => IngredientDictionary(id: '', name: '', rawVariants: []),
      );
      if (local.id.isNotEmpty) {
        return local;
      }
    } catch (_) {
      // 무시하고 서버 쪽으로 진행
    }

    // 2) 없으면 Firestore에서 직접 조회 (온라인일 때)
    try {
      final doc = await _db.collection('ingredients').doc(id).get();
      if (!doc.exists) return null;
      final data = doc.data()!;
      return IngredientDictionary.fromJson(data, doc.id);
    } catch (e, st) {
      // debugPrint('[IngredientDictionaryRepository] fetchById error: $e\n$st');
      return null;
    }
  }
}
