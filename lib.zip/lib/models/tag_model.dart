class TagModel {
  final String name;
  bool isSelected;

  TagModel(this.name, {this.isSelected = false});
}