// 레시피 정렬 모드
enum RecipeSortMode { nameAsc, nameDesc }

