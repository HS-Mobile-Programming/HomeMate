const String helpTitle1 = "집밥 메이트란?";

const String helpContent1 =
    "냉장고 속 재료를 효율적으로 관리하고, 유통기한 임박 알림을 받아보세요.\n"
    "내가 가진 재료로 만들 수 있는 맛있는 레시피도 추천해 드립니다!";

const String helpTitle2 = "주요 기능";

const String helpContent2 =
    "• 냉장고 재료 관리 및 유통기한 확인\n"
    "• AI 맞춤 레시피 추천\n"
    "• 나만의 즐겨찾기 레시피 저장";